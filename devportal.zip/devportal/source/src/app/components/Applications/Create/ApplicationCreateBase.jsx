import React from 'react';
import PropTypes from 'prop-types';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import { withStyles } from '@material-ui/core/styles';

/**
 * @inheritdoc
 * @param {*} theme theme object
 */
const styles = (theme) => ({
    createTitle: {
        color: theme.palette.getContrastText(theme.palette.background.default),
    },
    applicationContent: {
        '& span, & div, & p, & input': {
            color: theme.palette.getContrastText(theme.palette.background.paper),
        }
    }
});
/**
 * Base component for all API create forms
 *
 * @param {Object} props title and children components are expected
 * @returns {React.Component} Base element
 */
function ApplicationCreateBase(props) {
    const { title, children, classes } = props;
    return (
        <Box mt={5}>
            <Grid container spacing={3}>
                {/*
            Following two grids control the placement of whole create page
            For centering the content better use `container` props, but instead used an empty grid item for flexibility
             */}
                <Grid item sm={12} md={3} />
                <Grid item sm={12} md={6}>
                    <Grid container spacing={5}>
                        <Grid item md={12} className={classes.createTitle}>
                            {title}
                        </Grid>
                        <Grid item md={12} className={classes.applicationContent}>
                            <Paper elevation={0}>{children}</Paper>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Box>

    );
}
ApplicationCreateBase.propTypes = {
    title: PropTypes.element.isRequired,
    children: PropTypes.element.isRequired,
};
export default withStyles(styles)(ApplicationCreateBase);
