const Configurations = {
    /* Refer devportal/source/src/defaultTheme.js */
};
