/*
 * Copyright (c) 2019, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import React, { useContext, useState, useEffect } from 'react';
import { APIContext } from 'AppComponents/Apis/Details/components/ApiContext';
import { useAppContext } from 'AppComponents/Shared/AppContext';
import 'react-tagsinput/react-tagsinput.css';
import { FormattedMessage } from 'react-intl';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import { Link } from 'react-router-dom';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Checkbox from '@material-ui/core/Checkbox';
import Alert from 'AppComponents/Shared/Alert';
import Paper from '@material-ui/core/Paper';
import Tooltip from '@material-ui/core/Tooltip';
import { isRestricted } from 'AppData/AuthManager';
import { makeStyles } from '@material-ui/core/styles';
import MicroGateway from 'AppComponents/Apis/Details/Environments/MicroGateway';
import Kubernetes from 'AppComponents/Apis/Details/Environments/Kubernetes';
import API from 'AppData/api';

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    saveButton: {
        marginTop: theme.spacing(3),
    },
}));

/**
 * Renders an Environments list
 * @class Environments
 * @extends {React.Component}
 */
export default function Environments() {
    const classes = useStyles();
    const { api, updateAPI, isAPIProduct } = useContext(APIContext);
    const { settings } = useAppContext();
    const [gatewayEnvironments, setGatewayEnvironments] = useState([...api.gatewayEnvironments]);
    const [selectedMgLabel, setSelectedMgLabel] = isAPIProduct ? [] : useState([...api.labels]);
    const [isUpdating, setUpdating] = useState(false);
    const [selectedDeployments, setSelectedDeployments] = isAPIProduct ? [] : useState([...api.deploymentEnvironments]);
    const [isPublishing, setPublishing] = useState(false);
    const restApi = new API();
    const [allDeployments, setAllDeployments] = useState([]);
    useEffect(() => {
        restApi.getDeployments()
            .then((result) => {
                setAllDeployments(result.body.list);
            });
    }, []);

    /**
     *
     * Handle the Environments save button action
     */
    function addEnvironments() {
        setUpdating(true);
        updateAPI({
            gatewayEnvironments,
            labels: selectedMgLabel,
            deploymentEnvironments: selectedDeployments,
        })
            .then(() => Alert.info('API Update Successfully'))
            .catch((error) => {
                if (error.response) {
                    Alert.error(error.response.body.description);
                } else {
                    Alert.error('Something went wrong while updating the environments');
                }
                console.error(error);
            })
            .finally(() => setUpdating(false));
    }

    /**
     *
     * Handle the Environments publish button action
     */
    function addEnvironmentsAndPublish() {
        setPublishing(true);
        updateAPI({
            gatewayEnvironments,
            state: 'PUBLISHED',
        })
            .then(() => Alert.info('API Product Update Successfully'))
            .catch((error) => {
                if (error.response) {
                    Alert.error(error.response.body.description);
                } else {
                    Alert.error('Something went wrong while updating the environments');
                }
            })
            .finally(() => setPublishing(false));
    }

    const existSubscriptions = () => {
        api.operations.find((operation) => {
            return operation.verb === 'SUBSCRIPTION';
        });
    };

    return (
        <>
            <Typography variant='h4' component='h2' gutterBottom>
                <FormattedMessage
                    id='Apis.Details.Environments.Environments.APIGateways'
                    defaultMessage='API Gateways'
                />
            </Typography>
            <Paper className={classes.saveButton}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell align='left'>
                                <Typography variant='srOnly'>
                                    Action
                                </Typography>
                            </TableCell>
                            <TableCell align='left'>Name</TableCell>
                            <TableCell align='left'>Type</TableCell>
                            <TableCell align='left'>Server URL</TableCell>
                            <TableCell align='left'>Endpoint URLs</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {settings.environment.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell padding='checkbox'>
                                    <Checkbox
                                        data-testid={`environments-checkbox-${row.name}`}
                                        disabled={isRestricted(['apim:api_create', 'apim:api_publish'], api)}
                                        checked={gatewayEnvironments.includes(row.name)}
                                        inputProps={{ 'aria-label': 'select gateway ' + row.name }}
                                        onChange={
                                            (event) => {
                                                const { checked, name } = event.target;
                                                if (checked) {
                                                    setGatewayEnvironments([...gatewayEnvironments, name]);
                                                } else {
                                                    setGatewayEnvironments(
                                                        gatewayEnvironments.filter((env) => env !== name),
                                                    );
                                                }
                                            }
                                        }
                                        name={row.name}
                                        color='primary'
                                    />
                                </TableCell>
                                <TableCell component='th' scope='row'>
                                    {row.name}
                                </TableCell>
                                <TableCell align='left'>{row.type}</TableCell>
                                <TableCell align='left'>{row.serverUrl}</TableCell>
                                <TableCell align='left'>
                                    {api.isWebSocket() ? (
                                        <>
                                            <Tooltip
                                                placement='right'
                                                title={(
                                                    <>
                                                        <FormattedMessage
                                                            id={'Apis.Details.Environments.Environments.'
                                                                + 'APIGateways.EndpointUrls.Wss'}
                                                            defaultMessage='Gateway WebSocket Secure URL'
                                                        />
                                                    </>
                                                )}
                                            >
                                                <div>{row.endpoints.wss}</div>
                                            </Tooltip>
                                            <Tooltip
                                                placement='right'
                                                title={(
                                                    <>
                                                        <FormattedMessage
                                                            id={'Apis.Details.Environments.Environments.'
                                                                + 'APIGateways.EndpointUrls.Ws'}
                                                            defaultMessage='Gateway WebSocket URL'
                                                        />
                                                    </>
                                                )}
                                            >
                                                <div>{row.endpoints.ws}</div>
                                            </Tooltip>
                                        </>
                                    ) : (
                                        <>
                                            <Tooltip
                                                placement='right'
                                                title={
                                                    (api.isGraphql())
                                                        ? (
                                                            <FormattedMessage
                                                                id={'Apis.Details.Environments.Environments.'
                                                                    + 'APIGateways.EndpointUrls.GraphQL.Https'}
                                                                defaultMessage={'Gateway HTTPs URL for GraphQL'
                                                                    + ' Queries and Mutations'}
                                                            />
                                                        )
                                                        : (
                                                            <FormattedMessage
                                                                id={'Apis.Details.Environments.Environments.'
                                                                    + 'APIGateways.EndpointUrls.Https'}
                                                                defaultMessage='Gateway HTTPs URL'
                                                            />
                                                        )
                                                }
                                            >
                                                <div>{row.endpoints.https}</div>
                                            </Tooltip>
                                            <Tooltip
                                                placement='right'
                                                title={
                                                    (api.isGraphql())
                                                        ? (
                                                            <FormattedMessage
                                                                id={'Apis.Details.Environments.Environments.'
                                                                    + 'APIGateways.EndpointUrls.GraphQL.Http'}
                                                                defaultMessage={'Gateway HTTP URL for GraphQL'
                                                                    + ' Queries and Mutations'}
                                                            />
                                                        )
                                                        : (
                                                            <FormattedMessage
                                                                id={'Apis.Details.Environments.Environments.'
                                                                    + 'APIGateways.EndpointUrls.Http'}
                                                                defaultMessage='Gateway HTTP URL'
                                                            />
                                                        )
                                                }
                                            >
                                                <div>{row.endpoints.http}</div>
                                            </Tooltip>
                                        </>
                                    )}
                                    {api.isGraphql() && existSubscriptions && (
                                        <>
                                            <Tooltip
                                                placement='right'
                                                title={(
                                                    <>
                                                        <FormattedMessage
                                                            id={'Apis.Details.Environments.Environments.'
                                                                + 'APIGateways.EndpointUrls.GraphQL.Wss'}
                                                            defaultMessage={'Gateway WebSocket Secure'
                                                                + ' URL for GraphQL Subscriptions'}
                                                        />
                                                    </>
                                                )}
                                            >
                                                <div>{row.endpoints.wss}</div>
                                            </Tooltip>
                                            <Tooltip
                                                placement='right'
                                                title={(
                                                    <>
                                                        <FormattedMessage
                                                            id={'Apis.Details.Environments.Environments.'
                                                                + 'APIGateways.EndpointUrls.GraphQL.Ws'}
                                                            defaultMessage={'Gateway WebSocket'
                                                                + ' URL for GraphQL Subscriptions'}
                                                        />
                                                    </>
                                                )}
                                            >
                                                <div>{row.endpoints.ws}</div>
                                            </Tooltip>
                                        </>
                                    )}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Paper>

            {(!api.isWebSocket() && !isAPIProduct)
                && (
                    <MicroGateway
                        selectedMgLabel={selectedMgLabel}
                        setSelectedMgLabel={setSelectedMgLabel}
                        api={api}
                    />
                )}
            {
                allDeployments
                && (
                    allDeployments.map((clusters) => (clusters.name.toLowerCase() === 'kubernetes' && (
                        <Kubernetes
                            clusters={clusters}
                            selectedDeployments={selectedDeployments}
                            setSelectedDeployments={setSelectedDeployments}
                            api={api}
                        />
                    )))
                )
            }

            <Grid
                container
                direction='row'
                alignItems='flex-start'
                spacing={1}
            >
                <Grid item>
                    <Button
                        className={classes.saveButton}
                        disabled={isRestricted(['apim:api_create', 'apim:api_publish'], api) || isUpdating}
                        type='submit'
                        variant='contained'
                        color='primary'
                        onClick={addEnvironments}
                        data-testid={!isUpdating && 'save-environments-btn'}
                    >
                        <FormattedMessage
                            id='Apis.Details.Environments.Environments.save'
                            defaultMessage='Save'
                        />
                        {isUpdating && <CircularProgress size={20} />}
                    </Button>
                </Grid>
                {isAPIProduct && api.state !== 'PUBLISHED' && (
                    <Grid item>
                        <Tooltip
                            title={(
                                <FormattedMessage
                                    id='Apis.Details.Environments.Environments.publish.tooltip'
                                    defaultMessage='Publish to Gateways and Developer Portal'
                                />
                            )}
                            placement='bottom'
                            interactive
                        >
                            <Button
                                className={classes.saveButton}
                                disabled={isRestricted(['apim:api_publish'], api) || isPublishing}
                                type='submit'
                                variant='contained'
                                color='primary'
                                onClick={addEnvironmentsAndPublish}
                            >
                                <FormattedMessage
                                    id='Apis.Details.Environments.Environments.publish'
                                    defaultMessage='Publish'
                                />
                                {isPublishing && <CircularProgress size={20} />}
                            </Button>
                        </Tooltip>
                    </Grid>
                )}
                <Grid item>
                    <Button
                        className={classes.saveButton}
                        component={Link}
                        to={'/apis/' + api.id + '/overview'}
                    >
                        <FormattedMessage
                            id='Apis.Details.Environments.Environments.cancel'
                            defaultMessage='Cancel'
                        />
                    </Button>
                </Grid>
            </Grid>
            {isRestricted(['apim:api_create'], api) && (
                <Grid item>
                    <Typography variant='body2' color='primary'>
                        <FormattedMessage
                            id='Apis.Details.Environments.Environments.update.not.allowed'
                            defaultMessage={
                                '* You are not authorized to update particular fields of'
                                + ' the API due to insufficient permissions'
                            }
                        />
                    </Typography>
                </Grid>
            )}
        </>
    );
}
